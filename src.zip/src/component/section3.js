import React from "react";
import  "../styles/styles3.css";


function Section3()  {
    return ( 
        <div className="triadSection">
            <div className="sectionHeader">
                <h1>عکاسی با آیفون!</h1>
                <a href="/apps/370">بیشتر</a>
            </div>
            <div className="triadSwiperContainer">
                <div className="swiperWrapper2">
                    <div className="appGroupSwiper">
                        <div className="triadApp">
                            <a href="/i/86528921">
                            <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/64d4e871-37dd-48f9-82a6-7cd72059cb90-403e964f-a1bd-4da8-baf1-7e64a5097b9f/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Obscura 3 — Pro Camera"/>
                            </div>
                            <div className="info">
                                <p className="title">Obscura 3 — Pro Camera</p>
                                <p className="category">عکس و ویدئو</p>
                            </div>
                            </a>
                            <div className="appDownloaderButton">
                                <button className="button">دریافت</button>
                            </div>
                        </div>
                        <div className="triadApp">
                            <a href="/i/925537151">
                            <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/0e8d9f56-5efe-4b5b-b8cd-38eb0a617f2d-8ee064b8-e5d8-47ec-8e36-a5bcf5c627de/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Snapseed|اسنپ سید"/>
                            </div>
                            <div className="info">
                                <p className="title">Snapseed|اسنپ سید</p>
                                <p className="category">عکس و ویدئو</p>
                            </div>
                            </a>
                            <div className="appDownloaderButton">
                                <button className="button">دریافت</button>
                            </div>
                        </div>
                        <div className="triadApp">
                             <a href="/i/655201876">
                             <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/04332b85-3aa4-4da8-a0dd-048cba01e468-ada2543c-9b2c-4cb3-9191-f88d1f77c33d/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Slow Shutter Cam"/>
                            </div>
                            <div className="info">
                                <p className="title">Slow Shutter Cam</p>
                                <p className="category">عکس و ویدئو</p>
                            </div>
                            </a>
                            <div className="appDownloaderButton">
                                <button className="button">دریافت</button>
                            </div>
                        </div>
                    </div>
                    <div className="appGroupSwiper">
                        <div className="triadApp">
                             <a href="/i/368062089">
                             <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/97cdc20e-9459-488d-8bf6-8cf3a8a07ddf-5ef077ec-3bfa-4b47-ac4b-a91925249546/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="FILMIK"/>
                            </div>
                            <div className="info">
                                <p class="title">FiLMiC Firstlight - Photo App</p>
                                <p class="category">عکس و ویدئو</p>
                            </div>
                            </a>
                            <div className="appDownloaderButton">
                                <button className="button">دریافت</button>
                            </div>
                        </div>
                        <div className="triadApp">
                             <a href="/i/888344718">
                             <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/dd5237bd-9b5f-4972-88a9-b0f49abb3155-7844e2e2-bc9c-43d9-83ba-b9b4d9d2299c/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Manual"/>
                            </div>
                            <div className="info">
                                <p class="title">Manual Cam 4+</p>
                                <p class="category">عکس و ویدئو</p>
                            </div>
                            </a>
                            <div className="appDownloaderButton">
                                <button className="button">دریافت</button>
                            </div>
                        </div>
                        <div className="triadApp">
                            <a href="/i/25794218">
                            <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/34e5786d-8ae3-4fc2-94d8-146e7faa908e-59837f3d-8254-4057-b098-28bc6b4de342/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="ProShot "/>
                            </div>
                            <div className="info">
                                <p className="title">ProShot </p>
                                <p className="category">عکس و ویدئو</p>
                            </div>
                            </a>
                        <div className="appDownloaderButton">
                            <button className="button">دریافت</button>
                        </div>
                    </div>
                </div>  
                    <div className="appGroupSwiper">
                        <div className="triadApp">
                             <a href="/i/901832917">
                             <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/af8e605e-5530-4604-afa1-22c58f602ace-95f817a1-9a59-4203-b0f6-0d4b4461e7e0/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="FILMIK"/>
                            </div>
                            <div className="info">
                                <p class="title">Retrica-Original Filter Camera | رتریکا</p>
                                <p class="category">عکس و ویدئو</p>
                            </div>
                            </a>
                            <div className="appDownloaderButton">
                                <button className="button">دریافت</button>
                            </div>
                        </div>
                        <div className="triadApp">
                             <a href="/i/809150460">
                             <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/d86f6f0c-f830-452c-b3c0-85cba41febcd-44880675-a4c9-4e25-9006-acdc3a107427/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Manual"/>
                            </div>
                            <div className="info">
                            <p class="title">Afterlight 2 ++</p>
                                <p class="category">عکس و ویدئو</p>
                            </div>
                            </a>
                            <div className="appDownloaderButton">
                                <button className="button">دریافت</button>
                            </div>
                        </div>
                        <div className="triadApp">
                            <a href="/i/790956655">
                            <div className="iconWrapper">
                                <img className="icon" src="https://static.iapps.ir/apps/file/image/9ef4e288-073b-47c4-807e-ef48976ffec1-936ce2f3-e6ae-412a-8e69-51ac8e024639/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="ProShot "/>
                            </div>
                            <div className="info">
                                <p class="title">Camera+ 2</p>
                                <p className="category">عکس و ویدئو</p>
                            </div>
                            </a>
                        <div className="appDownloaderButton">
                            <button className="button">دریافت</button>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <hr className="separator"/>
        </div>
     );
}
 
export  default Section3;