import React from "react";
import  '../styles/styles1.css';

function Section1(){
  const openNewWindow = () => {
    window.open('/new-window' , '_blank', 'noopener , noreferrer');
  };
  const openNewArman = () => {
    window.open('/newArman' , '_blank', 'noopener , noreferrer');
  };
  const openNewFilimo = () => {
    window.open('/newFilimo' , '_blank', 'noopener , noreferrer');
  };


return(
    <div className="App">

      <div className="featuredApps" dir="rtl" align="right"></div>
        <div className="bannerSection" onClick={openNewWindow}>
          <div className="scrollerSwiperContainer ">
            <div className="swiperWrapper" >
              <a className="swiperSlide" href="/i/683182857" >
                <div className="banner">
                  <p className="label">امورمالی و پرداخت</p>
                  <h2 className="tittle">بلو بانک</h2>
                  <p className="subtitle">بانک ولی دوست‌داشتنی</p>
                  <img src="https://static.iapps.ir/apps/file/image/905ca777-91e8-405c-8787-a52116820dfb-6d5e8dc0-8326-44df-9471-bd5fa43458c4/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="بلو بانک"/>
                </div>
              </a>
               <a className="swiperSlide" onClick={openNewFilimo} href="/i/810802321" >
                <div className="banner">
                  <p className="label">سرگرمی</p>
                  <h2 className="tittle">فیلیمو</h2>
                  <p className="subtitle">کنترل همیشه دست توست!</p>
                  <img src="https://static.iapps.ir/apps/file/image/dbc7dbd7-ab46-4dd7-bc28-11af901de5f6-0ea09572-f162-4659-b9f0-4a791925d861/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو"/>
                </div>
              </a>
              <a className="swiperSlide"  onClick={openNewArman} href="/i/768789920" >
                <div className="banner">
                  <p className="label">ورزشی</p>
                  <h2 className="tittle">آرمان ورزش ورزشکار</h2>
                  <p className="subtitle">استلایتو بساز!</p>
                  <img src="https://static.iapps.ir/apps/file/image/7d484491-bde7-4e82-8a29-8249c5874b0b-ea994a58-be20-4fb4-8b9f-44b7dd16b424/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آرمان ورزش ورزشکار"/>
                </div>
              </a>
              <a className="swiperSlide"  href="/i/812849852" >
                <div className="banner">
                  <p className="label">رسانه</p>
                  <h2 className="tittle">آپارات</h2>
                  <p className="subtitle">بزرگترین سرویس اشتراک ویدیو!</p>
                  <img src="https://static.iapps.ir/apps/file/image/2092aff7-5d4c-4b5b-9619-ccc66d868766-3201fe2e-01eb-4ab7-b2ce-cc247ce7d8d5/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آپارات"/>
                </div>
              </a>
              <a className="swiperSlide" href="/i/465168417" >
                <div className="banner">
                  <p className="label">عکس و ویدئو</p>
                  <h2 className="tittle">Loopsie ++</h2>
                  <p className="subtitle">عکس‌هاتو زنده کن!</p>
                  <img src="https://static.iapps.ir/apps/file/image/da6d6944-f4ec-4ed4-bdc7-017e79573b9d-1a11e61c-15d7-44bd-b54b-74886853dc14/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Loopsie ++"/>
                </div>
              </a>
              <a className="swiperSlide" href="/i/99751580" >
                <div className="banner">
                  <p className="label">ابزار کاربردی</p>
                  <h2 className="tittle">آپ </h2>
                  <p className="subtitle">اپليکيشنی آسان برای زندگی آسان</p>
                  <img src="https://static.iapps.ir/apps/file/image/40b197e9-873f-49fc-8a20-7357abaa1986-c4b51752-f963-4f24-b92f-7274b59640dc/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آپ "/>
                </div>
              </a>
              <a className="swiperSlide" href="/i/521472675" >
                <div className="banner">
                 <p className="label">عکس و ویدئو</p>
                  <h2 className="tittle">AI Art Generator - GoArt ++</h2>
                  <p className="subtitle"> عکس‌هاتو به آواتار تبدیل کن!</p>
                  <img src="https://static.iapps.ir/apps/file/image/4182c2d5-c6f4-4d45-bc80-0a7a4cc2a9fb-db05b72e-ac77-4215-bf84-c6b9ccda443b/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="AI Art Generator - GoArt ++"/>
                </div>
              </a>
              <a className="" href="/i/202629508" >
                <div className="banner">
                  <p className="label">ابزار کاربردی</p>
                  <h2 className="tittle">Noir - Dark Mode for Safari</h2>
                  <p className="subtitle">وبگردی درحالت شب!</p>
                  <img src="https://static.iapps.ir/apps/file/image/b64ae5ed-8a12-4b5e-b1cb-c625ce56c944-9c88ab7d-ce81-44f7-ae4a-687fd7761a23/800x600.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Noir - Dark Mode for Safari"/>
                </div>
              </a>
            </div>
            <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
            <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
            <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
          </div>
          <hr class="separator"/>
        </div>
        </div>
)
    }
    export default Section1;