import React from "react";
import  "../styles/styles2.css";


function Section2()  {
    return ( 
      <div className="triadSection">
        <div className="sectionHeader">
          <h1>اپ‌های آنلاک شده 😉</h1>
          <a href="/apps/412">بیشتر</a>
        </div>
        <div className="triadSwiperContainer">
            <div className="swiperWrapper2">
              <div className="appGroupSwiper">
                <div className="triadApp">
                  <a href="/i/509801973">
                    <div className="iconWrapper">
                      <img className="icon" src="https://static.iapps.ir/apps/file/image/bf6846ab-2e2b-4b2f-b6af-104c98a1e1b2-6ca00c83-2ba4-427e-9983-52c4425d7bd7/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="VivaVideo ++ | ویوا ویدئو آنلاک‌شده" />
                    </div>
                    <div className="info">
                      <p className="title">VivaVideo ++ | ویوا ویدئو آنلاک‌شده</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/910751938">
                    <div className="iconWrapper">
                      <img className="icon"  src="https://static.iapps.ir/apps/file/image/84cce969-ed6e-4c01-931e-d28a54aa1e95-640eb546-7a98-40b5-948f-f38d77500e0d/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="StepsApp ++"/>
                    </div>
                    <div className="info">
                    <p className="title">StepsApp ++</p>
                      <p className="category">سلامتی و تناسب اندام</p>
                    </div>
                 </a>
                 <div className="appDownloaderButton">
                 <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/103094282">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/83103813-ae90-4316-aebe-8836c92bba10-414cf361-95d5-44a5-a405-27ba2345a7dc/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Reface: Face Swap Videos ++"/>
                    </div>
                    <div className="info">
                    <p className="title">Reface: Face Swap Videos ++</p>
                      <p className="category">سرگرمی</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
              </div>
              <div className="appGroupSwiper">
                <div className="triadApp">
                  <a href="/i/690396863">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/e5b2a0f7-4f7f-4975-8cf8-209d332a1020-16ec2c2e-4241-40f6-a8f9-5a7062273adc/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="اسپاتیفای | spotify ++"/>
                    </div>
                    <div className="info">
                    <p className="title">اسپاتیفای | spotify ++</p>
                      <p className="category">موسیقی</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/86557434">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/4863ef41-a4cc-4981-a800-ec18794bd358-4b912cea-a9c7-4e95-a878-f0fa46c05f96/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="BeautyPlus ++ | بیوتی پلاس"/>
                    </div>
                    <div className="info">
                    <p className="title">BeautyPlus ++ | بیوتی پلاس</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/163844239">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/3f46d2d0-fb03-4960-91ae-b93461017836-192c9cbf-0628-4c7a-8cdf-140cc7021d72/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="AirBrush ++ | ایربراش آنلاک‌شده"/>
                    </div>
                    <div className="info">
                    <p className="title">AirBrush ++ | ایربراش آنلاک‌شده</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
              </div>
              <div className="appGroupSwiper">
                <div className="triadApp">
                  <a href="/i/184565617">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/3af952dd-85b6-4bcd-a49d-56c6baf3cc2e-05da47c9-d0e1-4b2c-837e-c9af0f7a21cf/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt=" StoryChic - IG Story Templates ++"/>
                    </div>
                    <div className="info">
                    <p className="title"> StoryChic - IG Story Templates ++</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/271566690">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/549e9f47-e7f4-46bf-ab87-252d153d3b1f-a97d5e52-49b5-4128-8d63-aa2a252a8571/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="PicsArt ++ | پیکس آرت آنلاک‌شده"/>
                    </div>
                    <div className="info">
                    <p className="title">PicsArt ++ | پیکس آرت آنلاک‌شده</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/886882923">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/48638e38-b45d-405e-9ffe-effc0320f936-7e501d33-2363-442b-9aea-713d80202614/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Perfect365 ++"/>
                    </div>
                    <div className="info">
                    <p className="title">Perfect365 ++</p>
                      <p className="category">ابزار کاربردی</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
              </div>
              <div className="appGroupSwiper">
                <div className="triadApp">
                  <a href="/i/495364101">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/30e6ed1e-f583-46fb-b930-f3571abff321-3e949c3d-dd4f-439b-87a7-8872930f5625/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Notability ++"/>
                    </div>
                    <div className="info">
                      <p className="title">Notability ++</p>
                      <p className="category">ابزار کاربردی</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/780133549">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/2214ea47-d33f-4053-8a89-29ee62e491f6-b1d6047d-7aea-4441-972f-23d0d086fa3a/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Motionleap ++"/>
                    </div>
                    <div className="info">
                    <p className="title">Motionleap ++</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                  <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/594642552">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/4746d6d4-b59e-4867-b06c-6f9844a005a7-4b946652-c721-40c9-9e23-7cc9932620b0/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Inshot ++ | اینشات آنلاک‌شده"/>
                    </div>
                    <div className="info">
                    <p className="title">Inshot ++ | اینشات آنلاک‌شده</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
              </div>
              <div className="appGroupSwiper">
                <div className="triadApp">
                  <a href="/i/455182989">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/ae3f2f29-03c6-43d1-8667-7bd58669fa33-1d187cb2-cbad-4245-afec-bfa9d88e2936/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Home Workout ++"/>
                    </div>
                    <div className="info">
                    <p className="title">Home Workout ++</p>
                      <p className="category">سلامتی و تناسب اندام</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/308504666">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/fca3c994-d026-48ca-b85e-819404d3238e-c725ffa4-eb08-4e0f-8ad4-b6bd963a9110/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="VivaCut ++ | ویوا کات آنلاک‌شده"/>
                    </div>
                    <div className="info">
                    <p className="title">VivaCut ++ | ویوا کات آنلاک‌شده</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/603328729">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/fb15f237-231e-4ff6-87ae-2d2ec83c1495-e53b37fa-49c7-40bf-bc0a-aaf1b6c545cf/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="ABA English - Learn English ++"/>
                    </div>
                    <div className="info">
                    <p className="title">ABA English - Learn English ++</p>
                      <p className="category">منابع و آموزشی</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
              </div>
              <div className="appGroupSwiper">
                <div className="triadApp">
                  <a href="/i/539899578">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/2809b7b3-831c-4eb3-9a70-18d0b4dbc630-ba5f9fc2-4b45-40a8-98c7-236110c83bce/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Facetune 2 ++"/>
                    </div>
                    <div className="info">
                    <p className="title">Facetune 2 ++</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/48265648">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/d8a718eb-6f9a-4068-8b55-1990c0225d15-ddf0ddf7-cce5-4b18-8b4c-3e00a051d011/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Focos ++"/>
                    </div>
                    <div className="info">
                    <p className="title">Focos ++</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
                <div className="triadApp">
                  <a href="/i/487236450">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/adc5b27a-89f0-4986-882b-71077d6d4864-7d0bb748-608f-4b2d-8195-ebff9508560a/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Mondly ++ | ماندلی آنلاک‌شده"/>
                    </div>
                    <div className="info">
                    <p className="title">Mondly ++ | ماندلی آنلاک‌شده</p>
                      <p className="category">منابع و آموزشی</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                </div>
              </div>
              <div className="appGroupSwiper">
                <div className="triadApp">
                  <a href="/i/749267289">
                  <div className="iconWrapper">
                  <img className="icon"  src="https://static.iapps.ir/apps/file/image/12f49f17-bcbf-49a9-bef1-09f751fd36ae-9e4d2e55-8947-4bf8-974e-728687665a12/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Presets &amp; Filters - Koloro ++"/>
                    </div>
                    <div className="info">
                    <p className="title">Presets &amp; Filters - Koloro ++</p>
                      <p className="category">عکس و ویدئو</p>
                    </div>
                  </a>
                  <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                  </div>
                  </div>
                  <div className="triadApp">
                    <a href="/i/930617404">
                    <div className="iconWrapper">
                    <img className="icon"  src="https://static.iapps.ir/apps/file/image/c65aa0f1-7655-4437-b5b1-9c6543e6e505-0859ef50-bce8-4e40-a9e5-fdb8ec9a7bfe/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="TouchRetouch ++ | روتوش تصاویر"/>
                      </div>
                      <div className="info">
                      <p className="title">TouchRetouch ++ | روتوش تصاویر</p>
                        <p className="category">عکس و ویدئو</p>
                      </div>
                    </a>
                    <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                    </div>
                  </div>
                  <div className="triadApp">
                    <a href="/i/224725222">
                    <div className="iconWrapper">
                    <img className="icon"  src="https://static.iapps.ir/apps/file/image/0dbf611a-5e26-470e-9bf1-99a1e527e693-9913fa72-a64c-45be-a44f-6c31af010efc/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="EnhanceFox ++"/>
                      </div>
                      <div className="info">
                      <p className="title">EnhanceFox ++</p>
                        <p className="category">عکس و ویدئو</p>
                      </div>
                    </a>
                    <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                    </div>
                  </div>
                </div>
                <div className="appGroupSwiper">
                  <div className="triadApp">
                    <a href="/i/240441831">
                    <div className="iconWrapper">
                    <img className="icon"  src="https://static.iapps.ir/apps/file/image/1b1e3f3b-082b-41d6-8df3-039a94eda224-f17eaccb-98bd-47a9-a6c3-3f34a01cb1d8/118x118.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="Photoshop Express ++ | فتوشاپ آنلاک‌شده"/>
                      </div>
                      <div className="info">
                        <p className="title">Photoshop Express ++ | فتوشاپ آنلاک‌شده</p>
                        <p className="category">عکس و ویدئو</p>
                      </div>
                      </a>
                      <div className="appDownloaderButton">
                    <button className="button2">دریافت</button>
                      </div>
                    </div>
                  </div>
                </div>
                <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
                <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
                <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
                <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
                 <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
                <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
                <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
                <span className="swiperNotification" aria-live="assertive" aria-atomic="true"></span>
              </div>
              <hr className="separator"/>
            </div>
     );
}
 
export  default Section2;