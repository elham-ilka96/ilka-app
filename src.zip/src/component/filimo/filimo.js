import BoxIapps from "../featuredApps/boxIapps";
import "./filimo.css";

function FilimoApp() {
    return (  
        <div className="AppDetailsFilimo">
            <div className="viewnavigationBar">
                <a className="backButtonFilimo" href="#">
                    <img src="/images/icon-back.svg" alt=""/>
                </a>
            </div>
            <div className="cantainerFilimo">
                <div className="basicInfoFilimo">
                    <div className="appItemsFilimo">
                        <div className="appIconFilimo">
                            <img src="https://static.iapps.ir/apps/file/image/2bd509ef-ecf4-488d-b57a-a6a1e26042b0-199816bb-f9c0-459d-8d46-b4581cda0e88/250x250.jpg?
                            key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                      </div>
                    </div>
                </div> 
                <div className="detailsFilimo">
                    <h1>فیلیمو | Filimo </h1>
                    <p>سرگرمی</p>
                            <div className="appDownloaderbutton">
                                <button className="buttonFilimo">دریافت</button>
                            </div>
                </div>
            </div>  
            <div className="appRating">
            <div className="rating">
                <p className="rate">4.9</p>
                <div className="widgetRatings" title="4.9 Stars" >
                    <svg className="widgetGrad" >
                    <defs>
                    <linearGradient id="widgetGrad989901403832826" x1="0%" y1="0%" x2="100%" y2="0%">
                     <stop offset="0%" className="stopColorFirst" >
                    </stop>
                    <stop offset="0%" className="stopColorFirst" >
                    </stop>
                    <stop offset="0%" className="stopColorFinal" >
                    </stop>
                    <stop offset="100%" className="stopColorFinal" >
                    </stop>
                    </linearGradient>
                    </defs>
                    </svg>
                        <div className="widgetContainer" >
                         <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                        </svg>
                        </div>
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>   
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>            
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>                           
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>                                       
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>  
                    
                        <p className="rateCount">14
                            نظر</p>
                        
                    </div>
                </div>
                <div className="screenshotsFilimo">
                        <div className="scrollerFilimo">
                          <img class="" src="https://static.iapps.ir/apps/file/image/16b70d30-e8a6-46f0-a178-dc596dbbb48a-b0d080c2-ce1f-425f-894e-0ed1a45abf1c/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/5ba7aaed-bb14-4c11-a115-5549c7a8a7f0-6ef25861-87ac-4eba-8f6c-f97baed29587/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/92c686d9-dc8f-496c-ba5c-76bfc46453b5-e2c6a95c-9e7a-45df-9a71-000394708cb1/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/4f1799f9-3b07-4049-9c11-0ac70086a016-ab839a98-6e3a-41f5-9bf6-f4d6e374e3bd/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/98992467-a564-4218-808b-088802c30e6e-174bc382-571c-4285-b895-aff96adac783/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/f468c556-b44c-493c-a413-91786975f605-b94bfbe1-c1f6-4438-9351-ccea363ecc59/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/d6166ebf-f2e3-4cef-a085-da9a3f9b0f07-cd3d6534-5132-4a60-95c6-2f3d97f26350/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/80c0735a-88fa-442a-9f1a-cec8d756a056-04765de9-cc34-4ceb-b3ad-515a0d41cbf8/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                          <img class="" src="https://static.iapps.ir/apps/file/image/3ac5104f-2030-4e2c-8d9a-72e3a4e87fd9-6dd09b7d-2083-4cde-868e-6762414ba654/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="فیلیمو | Filimo "/>
                        </div>
                        <hr className="separatorFilimo"/>
                    </div>
                    <section itemprop="description" className="description">
                        <div>
                            <p>با اپلیکیشن فیلیمو، بیش از ۹۵۰۰۰ فیلم و سریال ایرانی و خارجی در جیب شماست!</p>
                             <br/>
                             <p>با اپلیکیشن فیلیمو، هر زمان و از هرجا، حتی بدون اینترنت، به آرشیوی از هزاران فیلم، سریال و برنامه ایرانی و خار...</p>
                        </div>
                        <a href="#" className="moreButtonFilimo">بیشتر</a>
                    </section>
                    <div className="developerFilimo2">
                        <div className="containerFilimo2">
                            <div className="detailsFilimo2">
                                <p>توسعه دهنده</p>
                                <a href="/developers/105316906">شرکت فناوران صباایده</a>
                            </div>
                            <a href="/developers/105316906">
                            <img src="https://app.iapps.ir/images/more.svg" alt=""/>
                            </a>
                        </div>
                        <hr className="separatorFilimo2"/>
                    </div>
                    <div className="changeLogfilimo">
                        <div className="containerfilimo3">
                            <h3>تغییرات آخرین نسخه</h3>
                            <div className="versionDetailsfilimo">
                                <p className="versionfilimo">نسخه 5.13.14</p>
                                <p className="versionfilimo">شنبه ۱۰ شهریور ۱۴۰۳</p>
                            </div>
                            <p className="changeLogTextfilimo">
                                <p>بهبود عملکرد</p>
                                <br/>
                            </p>
                            <a href="#" className="moreButtonFilimo">بیشتر</a>
                            <hr className="separatorFilimo2"/>
                        </div>
                    </div>
                    <div className="reviewRatingfilimo">
                        <div className="reviewRatingContainerfilimo">
                            <h3>نظر و امتیاز</h3>
                            <div className="ratingfilimo">
                                <p className="ratefilimo">4.9</p>
                                <p className="rateCountfilimo">از 14 امتیاز</p>
                            </div>
                            <div className="starRatingsfilimo">
                                <div className="star5Starinfo">
                                    <svg className="rcProgressline " viewBox="0 0 100 2" preserveAspectRatio="none">
                                        <path className="rcProgresslineTrail" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#f2f2f8" stroke-width="2" fill-opacity="0">
                                        </path>
                                        <path className="rcProgresslinePath5" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#8e8e93" stroke-width="2" fill-opacity="0">
                                        </path>
                                    </svg>
                                    <div className="widgetRatingsfilimo" title="5 Stars" >
                                        <svg className="widgetGradfilimo" >
                                        <defs>
                                        <linearGradient id="widgetGrad870226036339862" x1="0%" y1="0%" x2="100%" y2="0%">
                                        <stop offset="0%" className="stopcolorfirstfilimo" >
                                        </stop>
                                        <stop offset="0%" className="stopcolorfirstfilimo" >
                                        </stop>
                                        <stop offset="0%" className="stopcolorfinalfilimo" >
                                        </stop>
                                        <stop offset="100%" className="stopcolorfinalfilimo" >
                                        </stop>
                                        </linearGradient>
                                        </defs>
                                    </svg>
                                    <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>
                                    <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>
                                    <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>
                                    <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>
                                    <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>
                                </div>   
                               </div>

                           <div className="star4Starinfo">
                                <svg className="rcProgressline " viewBox="0 0 100 2" preserveAspectRatio="none">
                                <path className="rc-progress-line-trail" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#f2f2f8" stroke-width="2" fill-opacity="0">
                                </path>
                                <path className="rcProgresslinePath4" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#8e8e93" stroke-width="2" fill-opacity="0">
                                </path>
                                </svg>
                           
                           <div className="widgetRatingsfilimo" title="4 Stars" >
                                <svg className="widgetGradfilimo" >
                                <defs>
                                <linearGradient id="widgetGrad870226036339862" x1="0%" y1="0%" x2="100%" y2="0%">
                                    <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop>
                                    <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop>
                                    <stop offset="0%" className="stopcolorfinalfilimo" >
                                    </stop>
                                    <stop offset="100%" className="stopcolorfinalfilimo" >
                                    </stop>
                                </linearGradient>
                                </defs>
                                </svg>
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                </div>          
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>
                                    <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>
                                    <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                    </div>  
                                 </div> 
                                 </div> 
                                
                                <div className="star3Starinfo">
                                <svg className="rcProgressline " viewBox="0 0 100 2" preserveAspectRatio="none">
                                <path className="rc-progress-line-trail" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#f2f2f8" stroke-width="2" fill-opacity="0">
                                </path>
                                <path className="rcProgresslinePath3" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#8e8e93" stroke-width="2" fill-opacity="0">
                                </path>
                                    </svg>
                           
                           <div className="widgetRatingsfilimo" title="3 Stars" >
                                <svg className="widgetGradfilimo" >
                                <defs>
                                <linearGradient id="widgetGrad870226036339862" x1="0%" y1="0%" x2="100%" y2="0%">                           
                                <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop> 
                                    <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop>
                                    <stop offset="0%" className="stopcolorfinalfilimo" >
                                    </stop>
                                    <stop offset="100%" className="stopcolorfinalfilimo" >
                                    </stop>
                                    </linearGradient>                  
                                </defs>
                                </svg>
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                </div> 
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                </div> 
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                </div> 
                           </div>
                        </div>
                           <div className="star2Starinfo">
                                <svg className="rcProgressline " viewBox="0 0 100 2" preserveAspectRatio="none">
                                <path className="rc-progress-line-trail" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#f2f2f8" stroke-width="2" fill-opacity="0">
                                </path>
                                        <path className="rcProgresslinePath2" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#8e8e93" stroke-width="2" fill-opacity="0">
                                        </path>
                                    </svg>
                           
                           <div className="widgetRatingsfilimo" title="2 Stars" >
                                <svg className="widgetGradfilimo" >
                                <defs>
                                <linearGradient id="widgetGrad870226036339862" x1="0%" y1="0%" x2="100%" y2="0%">                           
                                <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop> 
                                    <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop>
                                    <stop offset="0%" className="stopcolorfinalfilimo" >
                                    </stop>
                                    <stop offset="100%" className="stopcolorfinalfilimo" >
                                    </stop>
                                    </linearGradient>     
                                    </defs>
                                </svg>
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                </div> 
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                </div> 
                             </div>
                             </div>

                             <div className="star1Starinfo">
                                <svg className="rcProgressline " viewBox="0 0 100 2" preserveAspectRatio="none">
                                <path className="rc-progress-line-trail" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#f2f2f8" stroke-width="2" fill-opacity="0">
                                </path>
                                        <path className="rcProgresslinePath1" d="M 1,1 L 99,1" stroke-linecap="round" stroke="#8e8e93" stroke-width="2" fill-opacity="0">
                                        </path>
                                    </svg>
                           
                             <div className="widgetRatingsfilimo" title="1Stars" >
                                <svg className="widgetGradfilimo" >
                                <defs>
                                <linearGradient id="widgetGrad870226036339862" x1="0%" y1="0%" x2="100%" y2="0%">                           
                                <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop> 
                                    <stop offset="0%" className="stopcolorfirstfilimo" >
                                    </stop>
                                    <stop offset="0%" className="stopcolorfinalfilimo" >
                                    </stop>
                                    <stop offset="100%" className="stopcolorfinalfilimo" >
                                    </stop>
                                    </linearGradient>  
                                    </defs>
                                </svg>
                                <div className="widgetContainerfilimo2" >
                                        <svg viewBox="0 0 51 48" className="widgetsvgWidgetselectedfilimo" >
                                            <path className="widgetfilimo2" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                                            </path>
                                        </svg>
                                </div>   
                            </div>
                        </div>
                        </div>            
                     </div>
                </div>                



            </div>
            <BoxIapps/>
        </div>
    );
}
export default FilimoApp;