import Toolbar from "./toolbar/toolbar"
import Section1 from "./section1";
import Section2 from "./section2";
import Section3 from "./section3";
import TabBar from "../tabBar";
import React from "react";


function Page1 () {
   
    return (
        <div>
            <Toolbar />
            <Section1/>
            <Section2/>
            <Section3/>
            <TabBar />
        </div>
    );
};

export default Page1;