import React, { useState, useEffect} from "react";
import "./toolbar.css";

const Toolbar= () => {
    const [fontSize, setFontSize] = useState(30);

    const handleScroll = () => {
        const scrollPosition = window.scrollY;

        const newSize = Math.max(20, 30 - scrollPosition / 10);
        setFontSize(newSize);
    };    
    
    useEffect(() => {

        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    return (
        <header className="toolbar">
        <div style={{height:'100vh',  position:"fixed", paddingRight:'15px', backgroundColor:""}}>
            

            <h1 style={{fontSize: `${fontSize}px`, transition:'font-size 0.2s ease' }}>
              ویترین
              </h1>
        </div>
        <hr className="separator"/>
       
        </header>
    );

};
export default Toolbar;