import React, {useState} from "react";
import  './account.css';

function  Account()  {
    const [phoneNumber, setPhoneNumber] = useState('');

    const handleInputChange = (e) => {
        const value = e.target.value;
        if (/^\d*$/.test(value)) {
            setPhoneNumber(value);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        alert(`شمارع: ${phoneNumber}`);
    };
    return ( 
        <div className="accountHome">
            <div className="loginaccount">
                <div className="phoneFormContainer">
                    <h2>ورود به حساب کاربری</h2>
                    <p>شماره تماس خود را در قسمت زیر وارد نمایید</p>
                    <form onSubmit={handleSubmit}>
                        <label for="phone" className="">شماره تماس</label>
                        <input  type="text" className="" value="" onChange={handleInputChange} placeholder="" maxLength={11}/>
                        <br/>
                        <p>   عضویت در آی‌اپس به منزله اطلاع از کلیه     

                         <a href="/terms" className="termsButton">
                           قوانین  
                        </a> 
                        و‌ پذیرش آنها می‌باشد.
                        </p>
                        <button className="buttonAccounts" type="submit" disabled="">بعدی</button>
                    </form>
                    </div>
                    <div className="tabBaraccunt">
                        <a className="tabbarItemAccunt" href="/vitrin">
                            <img src="https://app.iapps.ir/images/tab-bar-home.svg" alt="ویترین"/>
                            <p>ویترین</p>
                        </a>
                        <a className="tabbarItemAccunt" href="/apps">
                            <img src="https://app.iapps.ir/images/tab-bar-app.svg" alt="ویترین"/>
                            <p>برنامه ها</p>
                        </a>
                        <a className="tabbarItemAccunt" href="/games">
                            <img src="https://app.iapps.ir/images/tab-bar-game.svg" alt="ویترین"/>
                            <p>بازی ها</p>
                        </a>
                        <a className="tabbarItemAccunt" href="/search">
                            <img src="https://app.iapps.ir/images/tab-bar-search.svg" alt="ویترین"/>
                             <p>جستجو</p>
                        </a>
                        <a className="tabbarItemAccunt" href="/account">
                             <img src="https://app.iapps.ir/images/tab-bar-profile.svg" alt="حساب کاربری"/> 
                             <p>حساب کاربری</p>
                        </a>
                    </div>

                
            </div>
         </div>  
     );
}
 
export default Account;