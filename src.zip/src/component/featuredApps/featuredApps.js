import "./featuredApps.css";
import BoxIapps from "./boxIapps";

function FeaturedApps() {
    const openWindowAccount= () => {
        window.open('/newAccount' , '_blank', 'noopener , noreferrer');
      };
    return(
       <>
        
        <div className="featureDetails">
            <div className="viewNavigationBar">
                <a  href="#">
                <img src="https://app.iapps.ir/images/icon-back.svg" alt=""/>
                </a>
            </div>
            <div className="containerFeature1">
                <div className="basicInfo">
                    <div className="appItems">
                        <div className="appIcon">
                            <img src="https://static.iapps.ir/apps/file/image/6a9a3338-04ac-4bc9-bb4b-9fcd549a2169-deab0bc0-88cb-4045-ba33-608ef883ac6f/250x250.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="بلو - بانک ولی دوست‌داشتنی"/>
                        </div>
                        <div className="detailsFeature1">
                            <h1>بلو - بانک ولی دوست‌داشتنی</h1>
                            <p>امور مالی و پرداخت</p>
                            <div className="appdownloaderv2Button">
                                <button className="buttonFeature" onClick={openWindowAccount}>دریافت</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="screenshots">
                    <div className="scroller">
                        <img  src="https://static.iapps.ir/apps/file/image/12d5d70f-f33f-429e-94cd-d5685f69bfd6-ccecfdaa-1e58-4bb2-81b5-74afdf5e437a/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="بلو - بانک ولی دوست‌داشتنی"/>
                        <img  src="https://static.iapps.ir/apps/file/image/5ba347a6-b32b-4bb7-b08b-92182d2a70a9-ccf0fcc1-c543-4a8d-a996-e585e8c385dc/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="بلو - بانک ولی دوست‌داشتنی" />
                        <img  src="https://static.iapps.ir/apps/file/image/3b4924e7-7a9c-4c1d-b2ff-7c8af5e73557-dea2dd56-ecbb-42cb-8cee-87f95a936e86/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="بلو - بانک ولی دوست‌داشتنی" />
                        <img  src="https://static.iapps.ir/apps/file/image/c2e494fb-5df5-411d-90c8-35bb51c04c6b-2ba3c501-289c-44c3-814e-adbe6985e8f2/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="بلو - بانک ولی دوست‌داشتنی"/>
                        <img  src="https://static.iapps.ir/apps/file/image/4433f45b-03d8-4e3a-b025-ac9a2a0c7e1e-ca4b1774-7aa2-4a83-bba5-5c2a5b551798/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="بلو - بانک ولی دوست‌داشتنی" />
                    </div>
                    <hr className="separator" />
                </div>
                <section itemprop="description" className="description">
                    <div>
                        <p>بلوبانک سامان، پلتفرم تمام دیجیتال و مطابق با سبک جدید زندگی است که همه‌ی عملیات بانکداری روی اپلیکیشن موبایل و کاملا آنلاین انجام می‌شود.</p>
                        <br />
                        <p>کافی است با تلفن همراهتان وارد اپلیکیشن بلو شو...</p>
                    </div>
                    <a href="" className="moreButton">بیشتر</a>
                </section>
                <div className="developer">
                    <div className="containerFeature2">
                        <div className="details2">
                         <p>توسعه دهنده</p>
                         <a href="/developers/642161267">بلوبانک سامان</a>
                        </div>
                        <a href="/developers/642161267">
                            <img src="/images/more.svg" alt="" />
                        </a>
                    </div>
                    <hr className="separator"/>
                </div>
                <div className="changeLog">
                    <div className="containerFeature3">
                        <h3>تغییرات آخرین نسخه</h3>
                        <div className="versionDetails">
                            <p className="version">نسخه 3.1.0</p>
                            <p className="releaseDate">شنبه ۶ مرداد ۱۴۰۳</p>
                        </div>
                        <p className="changeLogText">
                            <ul>
                                <li>
                                    ویژگی های جدید
                                </li>
                                <li>
                                	واریز خودکار به باکس
                                </li>
                                <li>
                                    آپدیت گروهی دسته بندی تراکنش ها
                                </li>
                                <li>
                                •	اضافه شدن فیدبک در پروفایل
                                </li>
                                <li>
                                    امکان پین کردن مقصدهای انتقال یافته	
                                </li>
                                <li>
                                    ...
                                </li>
                            </ul>
                        </p>

                            <a href="#" className="moreButton">بیشتر</a>
                        <hr className="separator"/>
                    </div>
                </div>
                <div className="reviewRating">
                    <div className="reviewOntainer">
                        <h3>نظر و امتیاز</h3>
                    </div>
                </div>
                <div className="comments">
                    <div className="scroller"> </div>
                </div>
                <div className="writeReview">
                    <a href="/submitReview/84a25091-e8b0-475d-aa61-7d5fdb28f6d3-9227da1a-fbcf-46ef-887f-660a55a9e312">
                     نظر خود را بنویسید 
                        <img src="https://app.iapps.ir/images/icon-write-review.svg" />
                    </a>
                    <hr className="separator"/>
                </div>
                <div className="information">
                    <div className="infoContainer">
                        <h3>اطلاعات برنامه</h3>
                        <div className="infofeature">
                            <p className="titlefeature">سازگاری</p>
                             <p className="valuefeature">آیفون و آیپد</p>
                        </div>
                    <div className="infofeature">
                        <p className="titlefeature">دسته بندی</p>
                        <p className="valuefeature">امور مالی و پرداخت</p>
                    </div>
                    <div className="infofeature">
                        <p className="titlefeature">حجم</p>
                        <p className="valuefeature">143 مگابایت</p>
                    </div>
                    <div className="infofeature">
                        <p className="titlefeature">سازگاری با سیستم عامل</p>
                        <p className="valuefeature">14.0 به بالا</p>
                    </div>
                </div>
            </div>
        </div>
       
        </div>
        <BoxIapps/>
        </>
    );
}

export default FeaturedApps;