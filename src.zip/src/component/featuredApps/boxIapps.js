import React from "react";
import "./boxIapps.css";

function BoxIapps(){

    return(
        <>
            <div className="downloaderContainer">
            </div>
                <div className="installMessage">
                    <div className="arrowBox">
                        <div className="manual">
                            <strong>آی‌اپس را بر روی دستگاه خود نصب کنید</strong>
                            <br/>دکمه‌ی
                            <img className="imageFeature1" src="https://app.iapps.ir/images/share-icon-iphone-20.jpg" />
                             را لمس کنید و Add to Home Screen را انتخاب نمایید.
                        </div>
                        <img className="imageFeature2" src="https://app.iapps.ir/images/2Add_to_home_screen_icon.png" alt=""/>
                    </div>
                </div>
         </>
    )
}
export default BoxIapps;