import "./armanApp.css";
import BoxIapps from "../featuredApps/boxIapps";

function ArmanApp() {
    return (  
        <div className="AppDetailsArman">
            <div className="viewnavigationBar">
                <a className="backButtonArma" href="#">
                    <img src="/images/icon-back.svg" alt=""/>
                </a>
            </div>
            <div className="cantainerArman">
                <div className="basicInfoArman">
                    <div className="appItemsArman">
                        <div className="appIconArman">
                            <img src="https://static.iapps.ir/apps/file/image/5fe230b5-9db3-4e4e-9db9-8d9a057cb285-df6d404c-418c-4837-9e64-c0ac221dd179/250x250.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آرمان ورزش ورزشکار"/>
                        </div>
                        <div className="detailsArman">
                            <h1>آرمان ورزش ورزشکار</h1>
                            <p>سلامتی و تناسب اندام</p>
                            <div className="appDownloaderbutton">
                                <button className="buttonArman">دریافت</button>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        <div className="appRating">
            <div className="rating">
                <p className="rate">5</p>
                <div className="widgetRatings" title="5 Stars" >
                    <svg className="widgetGrad" >
                    <defs>
                    <linearGradient id="widgetGrad989901403832826" x1="0%" y1="0%" x2="100%" y2="0%">
                     <stop offset="0%" className="stopColorFirst" >
                    </stop>
                    <stop offset="0%" className="stopColorFirst" >
                    </stop>
                    <stop offset="0%" className="stopColorFinal" >
                    </stop>
                    <stop offset="100%" className="stopColorFinal" >
                    </stop>
                    </linearGradient>
                    </defs>
                    </svg>
                        <div className="widgetContainer" >
                         <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                        </svg>
                        </div>
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>   
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>            
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>                           
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>                                       
                        <div className="widgetContainer" >
                            <svg viewBox="0 0 51 48" className="widgetSvgwidgetSelected" >
                            <path className="widget" d="m25,1 6,17h18l-14,11 5,17-15-10-15,10 5-17-14-11h18z" >
                            </path>
                            </svg>
                        </div>  
                    
                        <p className="rateCount">3 
                            نظر</p>
                        
                    </div>
                    </div>
                    <div className="screenshotsArman">
                        <div className="scrollerArman">
                            <img className="" src="https://static.iapps.ir/apps/file/image/21c77db9-335b-44e9-bf51-dd574413edcd-bec3f21f-711b-4a34-8598-d307e07e512c/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آرمان ورزش ورزشکار" />
                            <img className="" src="https://static.iapps.ir/apps/file/image/38fd144a-3905-4c66-84e3-277cc6c99b8f-100c0a29-2349-4555-b14f-7fa0452f0157/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آرمان ورزش ورزشکار"/>
                            <img className="" src="https://static.iapps.ir/apps/file/image/1d3f38e6-5541-4bc3-9b7c-9b71b139e4db-6a988c7b-12c2-457d-b223-9a2b94ce362c/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آرمان ورزش ورزشکار"/>
                            <img className="" src="https://static.iapps.ir/apps/file/image/94005ce3-d9a1-4b53-bed6-1fdc9552321f-c05dccad-2e36-4b77-87c4-2c7fc6f9c6d5/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آرمان ورزش ورزشکار"/>
                            <img className="" src="https://static.iapps.ir/apps/file/image/247e04cc-03d0-4f35-b829-788148d7f2a6-aad9c608-b78f-4bb9-8b12-e5969c412e32/375x667.jpg?key=Ndu5E2g4BVBJVAwsDk82jSeThSw6CcKq" alt="آرمان ورزش ورزشکار"/>
                        </div>
                        <hr className="separatorArman"/>
                    </div>
                    <section itemprop="description" className="descriptionArman">
                        <div className="armanP">
                            <p>آرمان ورزش (آسان ورزش سابق) یا به اختصار "آو"</p>
                            <br/>
                            <p>شما می توانید از طریق این اپلیکیشن زیر نظر مربیان رسمی فدراسیون ها (فدراسیون بدنسازی و پرورش اندام ) ورزش کنید،</p>
                            <br/>
                            <p>درواق...</p>
                        </div>
                            <a href="#" className="morebuttonArman">بیشتر</a>
                    </section>





            </div>





        <BoxIapps/>
        </div>
    );
}
 
export default ArmanApp;