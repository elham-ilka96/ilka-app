import  "./App.module.css";
import Page1 from "./component/page1";

import { useEffect,useState } from "react";
import axios from "axios";
import { BrowserRouter as Router,Route, Routes} from "react-router-dom";
import  FeaturedApps from "./component/featuredApps/featuredApps";

import Account from "./component/phonnumber/account";
import ArmanApp from "./component/armanApp/armanApp";
import FilimoApp from "./component/filimo/filimo";

function App() {
  const [homeList, setHomeList] = useState([]);
  const [loading, setloading] = useState(true);
  

  useEffect(() => {
    axios.get('https://api.iapps.ir/apps/featured/home')
      .then(response => {
        setHomeList(response.data);
        setloading(false);
      });
},[]);

  if (loading){
    return (
    <div className="loadingSpinner">
      <div className="cssXim">
          <div className="cssO">
          </div>
          <div className="cssFwkynt">
          </div>
          <div className="cssHmllu">
           </div>
        </div>
        <p> صبر کنید</p>
  </div> 
    )
  }
  return (

    <div className="App">
      
        <Router>
            <Routes>
              <Route path="/" element={<Page1/>} />
              <Route path="/new-window" element={<FeaturedApps/>} />
              <Route path="/newAccount" element={<Account/>} />
              <Route path="/newArman" element={<ArmanApp/>} />
              <Route path="/newFilimo" element={<FilimoApp/>} />
              <Route path="/newBarVitrin" element={<Page1/>} />
              <Route path="/newBarPhon" element={<Account/>} />
            </Routes>
        
        </Router>
        

        
        {
          homeList.map(c => <div>
              <h3>
                {c.tittle}
              </h3>
              <img src={c.image} style={{maxWidth:200}} />
            </div>
          )
        }
      

      
       
        

        
        
  
  
      </div>
    
  );
}

export default App;

